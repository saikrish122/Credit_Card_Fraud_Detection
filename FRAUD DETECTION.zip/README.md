# Credit Card Fraud Detection: Deep Learning and MLOps Extension

A portfolio project comparing logistic regression, a cross-validated Random Forest, and two custom PyTorch multilayer perceptrons on imbalanced credit-card transaction data. Includes validation-based threshold selection, SHAP explanations, MLflow experiment tracking and a FastAPI serving application with Docker configuration.

**Status:** code package. No real-dataset results are bundled. Run the project and replace this status with verified results. See **START_HERE.md** for Windows instructions and **VALIDATION.md** for checks actually performed.

## Review feedback and concrete evidence

| Feedback | Implementation | Evidence after execution |
|---|---|---|
| Deep learning framework | PyTorch training loop with weighted binary cross-entropy | `.pt` checkpoints, epoch logs |
| Architecture design | 30 → 32 → 16 → 1 and 30 → 64 → 32 → 1; ReLU, dropout 0.2 | `neural.py`, metadata, validation AP |
| Hyperparameter optimization | RandomizedSearchCV, 4 configurations × 5 stratified folds, AP selection | `rf_cv_results.csv` |
| MLOps | MLflow parameters, epoch metrics, final metrics, artifacts, dataset hash | MLflow SQLite database and UI |
| Model serving | Shared preprocessing/inference code, FastAPI validation, health route | API tests and successful request |
| Container infrastructure | CPU Docker image and Compose mount | Successful local container build/run; must be verified separately |
| Explainability | Global and local Tree SHAP for the Random Forest | SHAP CSVs and plots |
| Quantified outcomes | AP, ROC-AUC, precision, recall, F1, confusion counts, inference timing | Generated metrics; no invented results |
| Business interpretation | Financial sensitivity scenarios | Explicitly simulated savings, not realized business impact |

This covers the specific feedback supplied in the conversation. It does not guarantee a resume threshold, production readiness, or any requirements not provided.

## Data and evaluation design

Dataset: [ULB credit-card fraud data on Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud). Supply your existing `creditcard.csv`; redistribution is not included. V1–V28 are anonymized PCA components, so their original business meanings cannot be recovered here. The API expects these same precomputed features and cannot score raw card details.

Exact duplicate rows are removed to reduce cross-split duplication. Because there is no reliable transaction ID, duplicates cannot be proved erroneous; this is a disclosed modeling choice that changes prevalence. Identical feature vectors with conflicting labels stop execution.

The outer split matches the supplied notebook's actual code: **25% development / 75% test**, stratified with seed 42. Inside development, 20% is reserved for validation, producing **20% train / 5% validation / 75% test** overall. This limits runtime but leaves few fraud examples for learning and validation. It sacrifices training data; it is not a generally preferred split.

The earlier notebook's text said 80/20 while its code used 25/75. This package documents the actual choice consistently. The same outer test partition was already evaluated in the earlier project if the CSV and row ordering are unchanged. Therefore results are **retrospective benchmark results**, not a pristine independent holdout. Random stratification also does not establish temporal generalization or performance on future transactions. A later temporal or external evaluation is needed for stronger evidence.

Random Forest hyperparameters are selected using training-only CV AP. Neural scalers are fitted only on training rows. Epoch checkpoints and architecture/model comparisons use validation AP. Each model's threshold maximizes validation F2, emphasizing recall. Reusing one small validation set for these choices can overfit it; this is a practical portfolio compromise, not nested evaluation. Models are not refitted after threshold selection, avoiding a threshold/model mismatch. The selected model is frozen before test scoring and is not changed because another model wins on test.

Average precision (AP) is reported by name, not mislabeled as accuracy or trapezoidal PR-AUC. Scores from class-weighted models are not calibrated probabilities. Accuracy alone is misleading for rare fraud. The code does not require the neural network to outperform the Random Forest.

## Neural architecture rationale

Thirty numeric inputs feed two small dense hidden layers. ReLU adds nonlinearity; dropout and weight decay limit overfitting. One output logit matches binary fraud detection. `BCEWithLogitsLoss` provides stable training and weights positive examples by training negative/positive count. Adam uses learning rate 0.001. Training is on CPU, with batches of 512, up to 20 epochs and four epochs of patience. The best validation-AP state is restored. Sigmoid is applied only for inference.

## Explainability and impact limits

Tree SHAP explains the **Random Forest only**, even when a different model is selected for serving. It checks additivity against RF probabilities. Global importance uses up to 100 randomly sampled validation rows; the local plot shows the highest-scored transaction within that sample. This is not necessarily fraud and is not a representative explanation of all fraud cases. SHAP is an attribution method, not proof of causality.

Cost scenarios assume prevention rates of 50% or 80%, review costs of 1 or 5 dataset-currency units per alert, and additional false-alert costs of 0 or 5. Baseline loss assumes all fraud amounts are lost. These are illustrative assumptions, not measured recoveries or company savings. Zero false-alert cost means omitted cost. The model was not optimized using test financial results.

## Serving scope

The API loads the validation-selected model and its original scaler/threshold. It validates the exact feature set, finite numeric values, nonnegative Time/Amount, and a maximum of 1,000 transactions per request. It exposes health and schema routes, and uses a non-root Docker user. The supplied Compose binding is local-only.

This is a **local serving demonstration**, not a production financial service. It has no authentication, TLS termination, operational alerting, online drift monitoring, rollback service or cloud deployment. No real cardholder data should be exposed through it. Only load model artifacts you trust. The local benchmark excludes HTTP, network delay and cold starts.

## Files

| File | Purpose |
|---|---|
| `Fraud_Detection_Extension.ipynb` | Beginner-friendly execution and learning guide |
| `core.py` | Data checks, splits, metrics and cost simulation |
| `neural.py` | Architecture and PyTorch training loop |
| `train.py` | Experiment, evaluation, SHAP and tracking orchestration |
| `predict.py` | Reusable model loading and inference |
| `app.py` | FastAPI service |
| `tests/test_pipeline.py` | Data, metric and API checks |
| `Dockerfile`, `compose.yaml` | Local container serving |
| `.github/workflows/tests.yml` | Core unit tests on push; serving test requires artifacts and is skipped in CI |

## References and attribution

This extension builds on Sai's supplied `Credit_Card_Fraud_Detection(4).ipynb` workflow and dataset choice. It does not copy the document-assistant repository. The extension was prepared with AI assistance; review and understand it before presenting it as your work.

- [PyTorch weighted binary cross-entropy](https://docs.pytorch.org/docs/stable/generated/torch.nn.BCEWithLogitsLoss.html)
- [SHAP TreeExplainer](https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html)
- [MLflow tracking API](https://mlflow.org/docs/latest/api_reference/python_api/mlflow.html)

Keep existing attribution/license notices for any additional code you later reuse.
